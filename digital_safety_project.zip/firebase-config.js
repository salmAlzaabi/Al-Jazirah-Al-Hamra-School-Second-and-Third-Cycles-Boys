
const firebaseConfig = {
  apiKey: "AIzaSyDjAGwFR11tX4i1JFFUW7ExRvVTYQVEMRs",
  authDomain: "jazira-1162c.firebaseapp.com",
  projectId: "jazira-1162c",
  storageBucket: "jazira-1162c.firebasestorage.app",
  messagingSenderId: "69759206540",
  appId: "1:69759206540:web:ad9e76ffdc769391ae27a9",
  measurementId: "G-H2RQ8E1E5H"
};
firebase.initializeApp(firebaseConfig);
    